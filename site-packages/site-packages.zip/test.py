from datetime import datetime, timedelta
from MensaParser import MensaParser

def mensa_parser_test():
    mp = MensaParser()
    today = mp.get_offer_for_date(datetime.now())
    preis_today = mp.how_much_for_offer(3)
    vegan_today = mp.is_vegan(1)
    gibt_es_vegan = mp.is_there_vegan();
    gibt_es_vegetarisch = mp.is_there_vegetarian();
    print(today)
    print(preis_today)
    print(vegan_today)
    print(gibt_es_vegan)
    print(gibt_es_vegetarisch)

    print("\n")
    tomorrow = mp.get_offer_for_date(datetime.today() + timedelta(days=1))
    preis_tom = mp.how_much_for_offer(3)
    vegetarisch_tom = mp.is_vegetarian(4)
    gibt_es_vegetarisch_tom = mp.is_there_vegetarian()

    print(tomorrow)
    print(preis_tom)
    print(vegetarisch_tom)
    print(gibt_es_vegetarisch_tom)



if __name__ == '__main__':
    mensa_parser_test()