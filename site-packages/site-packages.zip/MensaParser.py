import json, requests
from datetime import datetime

class MensaParser:
    def __init__(self):
        self.url = "https://www.studentenwerk-potsdam.de/essen/unsere-mensen-cafeterien/detailinfos/?tx_typoscriptrendering%5Bcontext%5D=%7B%22record%22%3A%22pages_66%22%2C%22path%22%3A%22tt_content.list.20.ddfmensa_ddfmensajson%22%7D&tx_ddfmensa_ddfmensajson%5Bmensa%5D=38&cHash=0843fa029901bdfc0e76d8f31eee7f56"
        self.mlist = self.__parse_url();
        self.current_day_data = [];

    #parses the url in json format and gives back a list with all the days and its menues
    def __parse_url(self):
        request = requests.get(self.url)
        raw_data = str(request.content)[2:-1]
        #convert the raw data into a json compliant dictionary
        raw_string = raw_data.replace(r'\\"', r"", 4)
        # raw_string = raw_data.replace(r"\/", r"/", 4)
        # raw_string = raw_string.replace(r'\n', r"")
        # raw_string = raw_string.replace(r"\u00e4", r"ä")
        # raw_string = raw_string.replace(r"\u00c4", r"Ä")
        # raw_string = raw_string.replace(r"\u00f6", r"ö")
        # raw_string = raw_string.replace(r"\u00d6", r"Ö")
        # raw_string = raw_string.replace(r"\u00fc", r"ü")
        # raw_string = raw_string.replace(r"\u00dc", r"Ü")
        # raw_string = raw_string.replace(r"\u00df", r"ß")


        j_data = json.loads(raw_string)

        #add all the daydata in a list and ignore weekend
        list = [];
        for x in j_data["wochentage"]:
            if int(x["datum"]["wochentag"]) < 6:
                list.append(x)
        return list

    #gives entry with respective date
    def get_offer_for_date(self,date):
        weekday = date.weekday()
        date = date.strftime("%d.%m.%Y")
        angebote = {}
        #read in the mensa offer into a dict
        for x in self.mlist:
            if x["datum"]["data"] == date:
                self.current_day_data = x
                angebote["datum"] = date
                for y in x["datum"]["angebote"]:
                    angebote["angebot" + str(y["index"])] = y["beschreibung"]
        return angebote

    def how_much_for_offer(self,index):
        preis = []
        for x in self.current_day_data["datum"]["angebote"]:
            if float(x["index"]) == index:
                preis.append(x["preis_s"])
                preis.append(x["preis_g"])
        return preis

    def is_vegan(self,index):
        vegan = 0
        for x in self.current_day_data["datum"]["angebote"]:
            if float(x["index"]) == index:
                if x["labels"][0]["name"] == "vegan":
                    vegan = 1
        return vegan

    def is_vegetarian(self, index):
        vegetarian = 0
        for x in self.current_day_data["datum"]["angebote"]:
            if float(x["index"]) == index:
                if x["labels"][0]["name"] == "vegetarisch":
                    vegetarian = 1
        return vegetarian

    def is_there_vegan(self):
        angebote_vegan = []
        for x in self.current_day_data["datum"]["angebote"]:
            if x["labels"][0]["name"] == "vegan":
                angebote_vegan.append("Angebot" + x["index"] + ", " + x["beschreibung"])
        return angebote_vegan;

    def is_there_vegetarian(self):
        angebote_vegetarisch = []
        for x in self.current_day_data["datum"]["angebote"]:
            if x["labels"][0]["name"] == "vegetarisch":
                angebote_vegetarisch.append("Angebot" + x["index"] + ", " + x["beschreibung"])
        return angebote_vegetarisch;










